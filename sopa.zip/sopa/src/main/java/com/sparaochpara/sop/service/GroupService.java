package com.sparaochpara.sop.service;

import com.sparaochpara.sop.dto.GroupDto;

import java.util.List;

public interface GroupService {

    List<GroupDto> findAllGroups();
}
