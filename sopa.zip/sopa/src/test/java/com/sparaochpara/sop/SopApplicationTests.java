package com.sparaochpara.sop;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
@Disabled
class SopApplicationTests {

	@Test
	void contextLoads() {
	}

}
